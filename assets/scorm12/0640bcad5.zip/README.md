<!--
author:    Hilke Domsch
email:     hilke.domsch@gkz-ev.de
date:      2026-01-24
version:   0.0.8

language:  de
narrator:  Deutsch Male

edit:      https://liascript.github.io/LiveEditor/?/github/Ifi-DiAgnostiK-Project/tischlerei-holzverbindungen

icon:      https://ifi-diagnostik-project.github.io/assets/img/Logo_234px.png
logo:      assets/images/woodwall_corner.jpg

title:     Holzverbindungen im Tischlerhandwerk
comment:   Typische Holzverbindungen im Tischlerhandwerk
attribute: "Quelle Titlebild: pixabay"
tags:      Gestellbau,
           Möbelbau,
           Holzverbindung,
           Holz,
           Tischler,
           Holzverbindungstechniken,
           Holzfügearten,
           Holzverbindungskonstruktionen,
           Holzbau,
           Rahmenbau,
           Korpusbau,
           Verbindungstechnik

link:      style.css
import:    https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/LiaScript_DragAndDrop_Template/refs/heads/main/README.md
           https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/Piktogramme/refs/heads/main/makros.md
           https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/Textilpflegesymbole/refs/heads/main/makros.md
           https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/LiaScript_ImageQuiz/refs/heads/main/README.md
           https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/Bildersammlung/refs/heads/main/makros.md
           https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/Tapetensymbole/refs/heads/main/makros.md
-->

# Typische Holzverbindungen - Überblickswissen

Holzverbindungen<!-- style="font-weight: bolder; font-size: 12pt; color: green;"--> sind das Fundament jeder stabilen und langlebigen Holzkonstruktion. Sie ermöglichen es, einzelne Holzbauteile sicher und präzise miteinander zu verbinden – sei es im Möbelbau, Innenausbau oder bei tragenden Konstruktionen. Dabei geht es nicht nur um Stabilität, sondern auch um Ästhetik, handwerkliche Qualität und die richtige Technik für den jeweiligen Einsatzzweck.

Holzverbindungen werden eingesetzt für:

<!-- class="explained" -->
- **Stabilität und Belastbarkeit**\
Holzverbindungen sorgen dafür, dass Bauteile dauerhaft und sicher miteinander verbunden sind.

- **Formgebung und Funktion**\
Holzverbindungen ermöglichen komplexe Formen und Konstruktionen, z. B. bei Möbeln, Türen oder Fenster.

- **Materialgerechtes Arbeiten**\
Holz "arbeitet" - es dehnt sich aus und zieht sich zusammen. Gute Verbindungen berücksichtigen diese Eigenschaften.

- **Ästhetik und Handwerkskunst**\
Sichtbare Verbindungen wie Zinken oder Schwalbenschwanzverbindungen zeigen handwerkliches Können und sind of gestalterisches Element.

<br>

<!--class="highlight"-->
Testen Sie Ihr Wissen zu den wichtigsten Holzverbindungen!

------------

<br> <br>


<center>

![Collage_Holzverbindung](assets/images/zinken_comparison_through.jpg "_Abbildung von zwei typischen Holzverbindungen, Fotos: HWK Dresden, Florian Riefling_")<!-- style="max-width: 550px; width: 100%" -->

</center>

## Erkennen & Benennen von typischen Holzverbindungen

Auf den folgenden Seiten sehen Sie Abbildungen von typischen Holzverbindungen in ihren Variationen im Tischlerhandwerk:

<!-- class="hash" -->
- Dübelverbindung
- Zapfenverbindung
- Schlitz-Zapfen-Verbindung
- offene Zinkung
- überblattete Verbindung
- durchbohrte und gezapfte Verbindung

<br>

<!-- class="highlight" -->
Ordnen Sie jeweils das Bild der richtigen Holzverbindung zu.

-----

<br> <br>


<center>

![Verschiedene Tischlerwerkzeuge, darunter Holzhammer, Pinsel, Stechbeitel, Gehrungslade, Axt und Holzdübel, liegen auf hellem Holzuntergrund.](assets/images/assortment_of_tools.jpg "Vorderansicht verschiedener Tischlerwerkzeuge auf hellem Holzuntergrund. Bild: Designed by [Freepik via Magnific](https://www.magnific.com/de/fotos-kostenlos/vorderansicht-verschiedene-tischlerwerkzeuge_9698135.htm), kostenloses Foto, Nutzung gemäß Magnific-/Freepik-Lizenz mit Namensnennung.")<!-- style="max-width: 550px; width: 100%" -->

</center>


### Holzverbindung 1

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Holzverbindung ist abgebildet?

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
- [( )] mit durchbohrten Dübel gesicherte Dominoverbindung
- [(X)] abgesetzte und durchbohrte Lochzapfenverbindung, mit Rundzapfen verkeilt
- [( )] offene Dübel-Zapfen-Verbindung
- [( )] verkeilte und durchbohrte Blattverbindung

</div>
<div class="flex-child-2 center">
![durchbohrt_und_gezapft](assets/images/Holzverb_rund_durch_auseinander.jpg "_Quelle: HWK Dresden, Florian Riefling_")<!-- style="max-width: 450px; width: 100%; margin-left:-50px; margin-top:10px;" -->

</div>
</section>

<center>

![durchbohrt_und_gezapft_fertig](assets/images/Holzverb_rund_durch.jpg)<!-- style="max-width: 450px; width: 100%" -->

</center>

### Holzverbindung 2

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Holzverbindung ist abgebildet?

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
- [(X)] gedübelte Verbindung
- [( )] durchbohrte und gezapfte Verbindung
- [( )] gezinkte Verbindung
- [( )] Schlitz-Zapfen-Verbindung

</div>
<div class="flex-child-2 center">

![Dübelverbindung](assets/images/Holzverb_duebel_zoom.jpg "_Quelle: HWK Dresden, Florian Riefling_")<!-- style="max-width: 550px; width: 100%; margin-left:-50px; margin-top:10px;" -->

</div>
</section>

<center>

![Dübelverbindung_groß](assets/images/Holzverb_duebel.jpg)<!-- style="max-width: 550px; width: 100%" -->

</center>

### Holzverbindung 3

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Holzverbindung ist abgebildet?

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
- [(X)] doppelte Schlitz-Zapfen-Verbindung
- [( )] einfache Schlitz-Zapfen-Verbindung
- [( )] Schwalbenschwanzverbindung
- [( )] Kreuzüberblattung

</div>
<div class="flex-child-2 center">

![doppelte_Schlitzverbindung](assets/images/Holzverb_platten.jpg "_Quelle: HWK Dresden, Florian Riefling_")<!-- style="max-width: 550px; width: 100%; margin-left:-50px; margin-top:10px;" -->

</div>
</section>

<center>

![doppelte_Schlitzverbindung_fertig](assets/images/Holzverb_platten_fertig.jpg)<!-- style="max-width: 550px; width: 100%" -->

</center>

### Holzverbindung 4

<section class="flex-container border">
<div class="flex-child">

><!--style="color: red; font-weight: bolder"-->Es sind zwei Aussagen richtig!

<!-- class="highlight" -->
Welche Holzverbindung ist abgebildet?

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
- [[X]] durchgehende Schwalbenschwanzverbindung
- [[ ]] verdeckte Zinkung
- [[X]] offene Zinkung
- [[ ]] Zargen-Schlitz-Verbindung

</div>
<div class="flex-child-2 center">
![Zinkung](assets/images/Holzverb_zinken.jpg "_Quelle: HWK Dresden, Florian Riefling_")<!-- style="max-width: 550px; width: 100%; margin-left:-50px; margin-top:10px;" -->

</div>
</section>

<center>

![Schwalbenschwanz_durchgehend](assets/images/zinken_auseinander.jpg)<!-- style="max-width: 450px; width: 100%" -->

</center>

### Holzverbindung 5

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Holzverbindung ist abgebildet?

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
- [( )] geschlitzte Rahmenverbindung
- [( )] abgesetzte Lochzapfenverbindung
- [( )] verdeckte Zapfenverbindung
- [(X)] Kreuzüberblattung

</div>
<div class="flex-child-2 center">

![Überplattung](assets/images/Holzverb_glue_auseinander.jpg "_Quelle: HWK Dresden, Florian Riefling_")<!-- style="max-width: 550px; width: 100%; margin-left:-50px; margin-top:10px;" -->

</div>
</section>

<center>

![Überplattung_fertig](assets/images/Holzverb_glue.jpg)<!-- style="max-width: 550px; width: 100%" -->

</center>

### Holzverbindung 6

<section class="flex-container border">
<div class="flex-child">

><!--style="color: red; font-weight: bolder"-->Es sind zwei Aussagen richtig!

<!-- class="highlight" -->
Welche Holzverbindung ist abgebildet?

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
- [[ ]] verdeckte Zapfenverbindung
- [[X]] Zapfenverbindung
- [[X]] abgesetzter Lochzapfen
- [[ ]] durchgehende Zapfen-Domino-Verbindung

</div>
<div class="flex-child-2 center">

![Lochzapfverbindung](assets/images/Holzverb_zapfen.jpg "_Quelle: HWK Dresden, Florian Riefling_")<!-- style="max-width: 550px; width: 100%; margin-left:-50px; margin-top:80px;" -->

</div>
</section>

<center>

![Lochzapfenverbindung_fertig](assets/images/Holzverb_zapfen_durch.jpg)<!-- style="max-width: 550px; width: 100%" -->

</center>

### Holzverbindung 7

<section class="flex-container border">
<div class="flex-child">

><!--style="color: red; font-weight: bolder"-->Es sind zwei Aussagen richtig!

<!-- class="highlight" -->
Welche Holzverbindung ist abgebildet?

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
- [[X]] Zapfenverbindung
- [[ ]] Nut-Feder-Verbindung
- [[X]] Dominoverbindung
- [[ ]] durchgehende Zapfen-Domino-Verbindung

</div>
<div class="flex-child-2 center">

![Dominoverbindung](assets/images/verbinder_langduebel_zoom.jpg "_Quelle: HWK Dresden, Florian Riefling_")<!-- style="max-width: 550px; width: 100%; margin-left:-50px; margin-top:80px;" -->

</div>
</section>

<center>

![Dominoverbindung_klein](assets/images/verbinder_langduebel.jpg)<!-- style="max-width: 550px; width: 100%" -->

</center>

### Holzverbindung 8

<section class="flex-container border">
<div class="flex-child">

><!--style="color: red; font-weight: bolder"-->Es sind zwei Aussagen richtig!

<!-- class="highlight" -->
Welche Holzverbindung ist abgebildet?

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
- [[X]] Schlitz-Zapfen-Verbindung
- [[X]] einfache Schlitz-Zapfen-Verbindung
- [[ ]] Schwalbenschwanzverbindung
- [[ ]] Spalt-Zapfen-Verbindung

</div>
<div class="flex-child-2 center">

![Schlitz_Zapfen_einfach](assets/images/schiebeverbinder.jpg "_Quelle: HWK Dresden, Florian Riefling_")<!-- style="max-width: 550px; width: 100%; margin-left:-50px; margin-top:80px;" -->

</div>
</section>

<center>

![Schlitz_Zapfen_fertig](assets/images/schiebeverbinder_zusammen.jpg)<!-- style="max-width: 550px; width: 100%" -->

</center>

### Holzverbindung 9

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Holzverbindung ist abgebildet?

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
- [( )] durchbohrte Dübelverbindung
- [(X)] verkeilte Rundzapfenverbindung
- [( )] verkeilte Dübelverbindung
- [( )] Spalt-Zapfen-Verbindung

</div>
<div class="flex-child-2 center">

![Rundzapfen_verkeilt_fertig](assets/images/loch_prepared_wall_winkel.jpg "_Quelle: HWK Dresden, Florian Riefling_")<!-- style="max-width: 550px; width: 100%; margin-left:-50px; margin-top:10px;" -->

</div>
</section>

<center>

![Rundzapfen_verkeilt](assets/images/loch_prepared_wall.jpg)<!-- style="max-width: 450px; width: 100%" -->

</center>

## Typische Einsatzgebiete und passende Verbindungen

Ob Rahmenbau, Möbelkorpus, Schubladenfront oder Bodenbelag – für jede Situation gibt es eine passende Verbindung, die Stabilität, Präzision und handwerkliche Qualität sicherstellt.

Die nachfolgenden Fragen testen, ob Sie den typischen Einsatzgebieten die jeweils passenden Holzverbindungen zuordnen können.

<!-- class="highlight" -->
Viel Erfolg!

<center>

![Holzwerkbank mit Werkzeugen und Holzbrettern für Tischler- oder Heimwerkerarbeiten.](assets/images/wood_signed.jpg "Werkbank mit Werkzeugen und Holz für Tischlerarbeiten. Bild von [azboomer via Pixabay](https://pixabay.com/photos/carpentry-hobby-work-bench-tools-854287/), Pixabay Content License, veröffentlicht am 22. Juli 2015.")<!-- style="max-width: 550px; width: 100%" -->

</center>


### Einsatzgebiete von Holzverbindungen - Teil 1

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Holzverbindung wird typischerweise für stabile Rahmenkonstruktionen wie Türen und Fenster verwendet?

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
- [( )] Gehrungsverbindung
- [(X)] Schlitz-Zapfen-Verbindung
- [( )] verkeilte Dübelverbindung
- [( )] Nut-Feder-Verbindung
********************
"Die Schlitz-Zapfen-Verbindung ist eine der stabilsten klassischen Holzverbindungen und ideal für Rahmen."
********************

</div>
</section>

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Holzverbindung eignet sich besonders für den Korpusbau?

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
- [( )] Überblattung
- [(X)] Fingerzinken (Zinkenverbindung)
- [( )] Schwalbenschwanzverbindung
- [( )] Schraubenverbindung
********************
"Fingerzinken bieten eine große Leimfläche und sind perfekt für stabile Möbelkorpusse."
********************

</div>
<div class="flex-child">

![Quiz_Tastatur](assets/images/quiz_on_keyboard.jpg "[_Quelle: Pixabay_](https://pixabay.com/photos/carpentry-hobby-work-bench-tools-854287/)")<!-- style="max-width: 350px; width: 100%; margin-left: 20px; margin-top:60px;" -->

</div>
</section>

### Einsatzgebiete von Holzverbindungen - Teil 2

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Holzverbindung wird typischerweise bei Bodenbelägen und Paneelen eingesetzt?

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
- [( )] Dübelverbindung
- [(X)] Nut-Feder-Verbindung
- [( )] Fingerzinken-Verbindung
- [( )] Überblattung
********************
"Eine Nut-Feder-Verbindung sorgt für flächige, bündige Holzoberflächen."
********************

</div>
<div class="flex-child">

![Symbol eines Fragebogens mit Fragezeichen und Häkchen für Quiz, Fragen oder Umfragen.](assets/images/checks_and_question.png "Fragebogen-Symbol für Quiz, Fragen und Lösungen. Bild von [HandiHow via Pixabay](https://pixabay.com/de/vectors/symbol-quiz-fragen-fragebogen-6065371/), Pixabay Content License, veröffentlicht am 4. März 2021.")<!-- style="max-width: 250px; width: 100%; margin-left: 40px; margin-top:20px;" -->


</div>
</section>

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Holzverbindung wird häufig bei Schubladen eingesetzt, weil sie hohe Zugkräfte aufnehmen kann?

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
- [( )] Überblattung
- [( )] Nut-Feder-Verbindung
- [(X)] Schwalbenschwanzverbindung
- [( )] Schraubenverbindung
********************
"Eine Schwalbenschwanzverbindung verhindert ein Auseinanderziehen - ideal für Schubladenfronten."
********************

</div>
</section>

### Einsatzgebiete von Holzverbindungen - Teil 3

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Holzverbindung wird in der Regel genutzt, wenn eine unsichtbare, aber stabile Verbindung im Möbelbau gewünscht ist?

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
- [( )] Lochzapfenverbindung
- [(X)] Dübelverbindung
- [( )] Überblattung
- [( )] versenkte Schlitz-Zapfen-Verbindung
********************
"Dübel sind außen nicht sichtbar und bieten gute Stabilität."
********************

</div>
</section>

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Holzverbindung eignet sich besonders für lange, durchgehende Holzbauteile wie Konstruktions- oder Rahmenholz?

<!--
data-randomize
data-solution-button="off"
data-max-trials="3"
-->
- [( )] Nut-Feder-Verbindung
- [(X)] Keilzinkenverbindung
- [( )] Schwalbenschwanzverbindung
- [( )] Dominoverbindung
********************
"Keilzinken sind eine industrielle Methode zur Längsverbindung (Verlängerung) von Holzstäben o. ä., bei der eine Vielzahl sehr kleiner Keile ineinander verleimt wird.\
Eine Schwalbenschwanzverbindung ist eine handwerklich anspruchsvolle, formschlüssige Eckverbindung, welche im Fall von Leimholzplatten viel zu aufwändig für den Zweck wäre."
********************

</div>
<div class="flex-child">

![KI-generierte Illustration einer Person, die an einem Laptop eine digitale Checkliste mit Aufgaben, Umfrage-, Prüfungs- und Quizpunkten bearbeitet.](assets/images/computer_hover_test.jpg "Digitale Checkliste auf einem Laptop als Symbol für Aufgaben, Online-Bewertungen und geschäftliche Technologie. Bild von [JonathanPrestes via Pixabay](https://pixabay.com/de/illustrations/ai-generiert-gesch%C3%A4ft-technologie-9371381/), Pixabay Content License, veröffentlicht am 2. Februar 2025.")<!-- style="max-width: 350px; width: 100%; margin-left: 20px; margin-top:20px;" -->

</div>
</section>

## Geschafft 🎉

![Bunte Silhouetten mehrerer springender Menschen vor weißem Hintergrund als Symbol für Freude, Spaß und Lebensfreude.](assets/images/colorfull_jumping.jpg "Farbige Silhouetten springender Menschen als Ausdruck von Freude und Spaß. Bild von [geralt via Pixabay](https://pixabay.com/de/illustrations/freude-springen-luftsprung-spa%C3%9F-3940425/), Pixabay Content License, veröffentlicht am 19. Januar 2019.")
