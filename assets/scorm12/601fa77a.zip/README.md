<!--
author:    Hilke Domsch
email:     hilke.domsch@gkz-ev.de
date:      2025-09-12
version:   0.0.5

language:  de
narrator:  Deutsch male

edit:      https://liascript.github.io/LiveEditor/?/github/Ifi-DiAgnostiK-Project/tischlerei-oberflaeche-tso12-einfach

icon:      https://ifi-diagnostik-project.github.io/assets/img/Logo_234px.png
logo:      assets/images/woodboard.jpg

title:     Oberflächenveredelung Tischlerhandwerk TSO 1+2/24
attribute: Oberflächenveredlung I TSO 1/2024, Oberflächenveredlung II TSO 2/2024,
           einfache Fragen
comment:   Einfache Fragen Oberflächengestaltung und Oberflächenbearbeitung Holz
tags:      Oberflächenveredelung,
           Tischler,
           Schleifen,
           Ölen,
           Lacke

link:      style.css
import:    https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/LiaScript_DragAndDrop_Template/refs/heads/main/README.md
           https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/Piktogramme/refs/heads/main/makros.md
           https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/Textilpflegesymbole/refs/heads/main/makros.md
           https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/LiaScript_ImageQuiz/refs/heads/main/README.md
           https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/Bildersammlung/refs/heads/main/makros.md
-->

# Oberflächenveredelung Tischlerhandwerk TSO 1+2/24

<!-- class="highlight" -->
Einfache Fragen
===

<!-- class="highlight; color: black" -->
Die Oberflächenbehandlung und -veredelung ist ein zentrales Thema im Tischler- und Schreinerhandwerk. Sie sorgt nicht nur für eine ansprechende Optik, sondern schützt Holzoberflächen auch dauerhaft vor Feuchtigkeit, Schmutz und Abnutzung.
<br> <br>
Im Rahmen Ihrer Ausbildung haben Sie sich mit den wichtigsten Verfahren – vom Schleifen über das Beizen bis hin zum Lackieren, Ölen oder Wachsen – beschäftigt. Sie wissen, dass sowohl die Holzart, als auch die Nutzungsanforderungen und die gestalterischen Aspekte eine wesentliche Rolle spielen.
<br> <br>
Die nachfolgenden Fragen dienen dazu, Ihr Wissen zu prüfen und zu festigen. Es soll Ihnen helfen, das Gelernte aktiv abzurufen und mit Freude in die praktische Arbeit einzubringen.

<!-- class="highlight" -->
Wir wünschen Ihnen viel Erfolg und Spaß beim Beantworten der Fragen!

<br>
<center>
![Hand eines Tischlers schleift ein Stück Holz.](assets/images/rotating_sander.jpg "Schreinerarbeit beim Schleifen von Holz. Bild von [Detmold via Pixabay](https://pixabay.com/de/photos/tischler-schreiner-handwerk-3276186/), Pixabay Content License, veröffentlicht am 30. März 2018.")<!-- style="max-width: 600px; width: 100%" -->
</center>

## Vorbereiten der Oberfläche - einfache Fragen

<!-- class="highlight" -->
Was gehört zu den vorbereitenden Maßnahmen vor dem Ölen einer Holzoberfläche?\
Ziehen Sie den richtigen Begriff ins Antwortfeld.

<!-- data-randomize data-show-partial-solution -->
@dragdropmultiple(@uid,Schleifen,Lackieren|Bohren|Zinken)


<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Vorbehandlung wird oft zwischen zwei Schleifgängen durchgeführt, um Holzfasern aufzurichten?

<!-- data-randomize -->
- [( )] Grundieren
- [(X)] Wässern
- [( )] Lackieren
- [( )] Polieren

</div>
<div class="flex-child-2 center">
![Rotes Fragezeichen als Symbol für Fragen, Hilfe und Antworten.](assets/images/fragezeichen.jpg "Fragezeichen als Symbol für Fragen, Hilfe und Antworten. Bild von [geralt via Pixabay](https://pixabay.com/de/photos/frage-fragezeichen-hilfe-antwort-2309042/), Pixabay Content License.")<!-- style="max-width: 200px; width: 100%" -->

</div>
</section>


## Beizen - einfache Fragen

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Was wird durch das Beizen von Holz erreicht?

<!-- data-randomize -->
- [( )] eine glatte Oberfläche
- [(X)] eine Farbtonveränderung
- [( )] ein chemischer Schutz
- [( )] ein Hitzeschutz

</div>
<div class="flex-child-2 center">

![KI-generierte Holz-Tischplatte mit sichtbarer Maserung und unscharfem Werkstatt-Hintergrund.](assets/images/woodboard.jpg "KI-generierte Holz-Tischplatte mit natürlicher Maserung. Bild von [TyliJura via Pixabay](https://pixabay.com/de/illustrations/ai-generiert-holz-tischplatte-9775119/), Pixabay Content License, veröffentlicht am 15. August 2025.") <!-- style="max-width: 300px; width: 100%" -->

</div>
</section>

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Art von Beize wirkt durch eine chemische Reaktion mit dem Holz?

<!-- data-randomize -->
- [( )] Farbstoffbeize
- [(X)] chemische Beize
- [( )] Ölbeize
- [( )] Substratbeize

>_Florian: Wenn weitere Bilder eingebracht werden sollen, dann bitte welche zur Verfügung stellen!_

</div>
</section>

## Überzugsmittel - einfache Fragen

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welcher Stoff gehört zu den natürlichen Überzugsmitteln?\
Ziehen Sie den richtigen Begriff ins Antwortfeld.

<!-- data-randomize data-show-partial-solution-->
@dragdropmultiple(@uid,Leinöl,Acrylharz|Nitrolack|PU-Lack)

</div>
</section>

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Eigenschaft ist typisch für physikalisch trocknende Überzugsmittel?

<!-- data-randomize -->
- [( )] Sie härten durch chemische Reaktion.
- [(X)] Sie trocknen durch Verdunstung des Lösungsmittels.
- [( )] Sie benötigen UV-Licht.
- [( )] Sie werden mit Wasser vermischt.


</div>
<div class="flex-child-2 center">

![KI-generierte helle Holz- bzw. Sperrholzoberfläche in Draufsicht mit sichtbarer Maserung.](assets/images/distinctwoodbig.jpg "Helle Holz- bzw. Sperrholztextur als Hintergrund. Bild von [Yamu_Jay via Pixabay](https://pixabay.com/de/illustrations/ai-generiert-holz-sperrholz-9000867/), Pixabay Content License, veröffentlicht am 30. August 2024.") <!-- style="max-width: 300px; width: 100%" -->

</div>
</section>

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Worin liegt der Unterschied zwischen physikalisch und chemisch härtenden Lacken?

<!-- data-randomize -->
- [( )] Farbe
- [(X)] Aushärtungsverfahren
- [( )] Glanzgrad
- [( )] Holzartunabhängigkeit

</div>
</section>


## Oberflächentechniken - einfache Fragen

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Was ist eine typische Methode zur Mattierung einer Holzoberfläche?

<!-- data-randomize -->
- [( )] Lackieren und Anschleifen
- [(X)] Beimischen von Teilchen in den Decklack
- [( )] Beizen
- [( )] zweimal Grundieren

</div>
<div class="flex-child-2 center">

![Eine Hand streicht mit einem Pinsel graue Farbe auf eine Holzoberfläche.](assets/images/grey_paint_on_wood.jpg "Holzoberfläche wird mit einem Pinsel grau gestrichen. Bild von [penphoto via Pixabay](https://pixabay.com/photos/brush-painting-wood-table-hand-6490442/), Pixabay Content License, veröffentlicht am 27. Juli 2021.") <!-- style="max-width: 150px; width: 100%" -->

</div>
</section>

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welches Verfahren ist ~~nicht~~ typisch für den Lackauftrag?\
Ziehen Sie den entsprechenden Begriff ins Antwortfeld.

<!-- data-randomize data-show-partial-solution -->
@dragdropmultiple(@uid,Hobeln,Fluten|Spritzen|Tauchen)

</div>
</section>

## Trocknungs- und Härteverfahren - einfache Fragen

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Energieform wird bei der UV-Härtung verwendet?\
Ziehen Sie den richtigen Begriff ins Antwortfeld.

<!-- data-randomize data-show-partial-solution -->
@dragdropmultiple(@uid,Ultraviolettes Licht,Warmluft|Mikrowellen|Wasserdampf)

</div>
</section>

<center>
![Rotes Fragezeichen als Symbol für Fragen, Hilfe und Antworten.](assets/images/fragezeichen.jpg "Fragezeichen als Symbol für Fragen, Hilfe und Antworten. Bild von [geralt via Pixabay](https://pixabay.com/de/photos/frage-fragezeichen-hilfe-antwort-2309042/), Pixabay Content License.")<!-- style="max-width: 300px; width: 100%" -->
</center>

## Sicherheit und Umweltschutz - einfache Fragen

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Wie sind ölgetränkte Lappen sicher zu entsorgen?

<!-- data-randomize -->
- [( )] in der Restmülltonne
- [(X)] in einem Metallbehälter mit Deckel
- [( )] im Altpapier
- [( )] im Waschbecken

</div>
</section>

<center>
![Sicher](assets/images/sicher_aus_schildern.jpg "_Quelle: Pixabay, Peggy+Marco_")<!-- style="max-width: 500px; width: 100%" -->
</center>

## Geschafft! 🙌


<center>
![Bunte Silhouetten mehrerer springender Menschen vor weißem Hintergrund als Symbol für Freude, Spaß und Lebensfreude.](assets/images/colorfull_jumping.jpg "Farbige Silhouetten springender Menschen als Ausdruck von Freude und Spaß. Bild von [geralt via Pixabay](https://pixabay.com/de/illustrations/freude-springen-luftsprung-spa%C3%9F-3940425/), Pixabay Content License, veröffentlicht am 19. Januar 2019.")
</center>
