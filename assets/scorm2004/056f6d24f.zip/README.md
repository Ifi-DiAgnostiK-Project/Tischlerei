<!--
author:    Hilke Domsch
email:     hilke.domsch@gkz-ev.de
date:      2025-09-12
version:   0.0.3

language:  de
narrator:  Deutsch male

edit:      https://liascript.github.io/LiveEditor/?/github/Ifi-DiAgnostiK-Project/tischlerei-oberflaeche-tso12-mittel

icon:      https://ifi-diagnostik-project.github.io/assets/img/Logo_234px.png
logo:      assets/images/woodboard.jpg

title:     Oberflächenveredelung Tischlerhandwerk TSO 1+2/24
comment:   Mittelschwere Fragen Oberflächengestaltung und
           Oberflächenbearbeitung Holz
attribute: title image Von Bundesarchiv, Bild 183-41030-0002 / Draum /
           CC-BY-SA 3.0, CC BY-SA 3.0 de,
           https://commons.wikimedia.org/w/index.php?curid=5428443
attribute: Oberflächenveredlung I TSO 1/2024, Oberflächenveredlung II
           TSO 2/2024, mittelschwere Fragen
tags:      Oberflächenveredelung,
           Tischler,
           Schleifen,
           Ölen,
           Lacke

link:      style.css
import:    https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/LiaScript_DragAndDrop_Template/refs/heads/main/README.md
           https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/Piktogramme/refs/heads/main/makros.md
           https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/Textilpflegesymbole/refs/heads/main/makros.md
           https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/LiaScript_ImageQuiz/refs/heads/main/README.md
           https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/Bildersammlung/refs/heads/main/makros.md
-->

# Oberflächenveredelung Tischlerhandwerk TSO 1+2/24
<!-- class="highlight" -->
Mittelschwere Fragen
===

<!-- class="highlight; color: black" -->
Die Oberflächenbehandlung und -veredelung ist ein zentrales Thema im Tischler- und Schreinerhandwerk. Sie sorgt nicht nur für eine ansprechende Optik, sondern schützt Holzoberflächen auch dauerhaft vor Feuchtigkeit, Schmutz und Abnutzung.
<br> <br>
Im Rahmen Ihrer Ausbildung haben Sie sich mit den wichtigsten Verfahren – vom Schleifen über das Beizen bis hin zum Lackieren, Ölen oder Wachsen – beschäftigt. Sie wissen, dass sowohl die Holzart, als auch die Nutzungsanforderungen und die gestalterischen Aspekte eine wesentliche Rolle spielen.
<br> <br>
Die nachfolgenden Fragen dienen dazu, Ihr Wissen zu prüfen und zu festigen. Es soll Ihnen helfen, das Gelernte aktiv abzurufen und mit Freude in die praktische Arbeit einzubringen.

<!-- class="highlight" -->
Wir wünschen Ihnen viel Erfolg und Spaß beim Beantworten der Fragen!

<br>
<center>
![Hände schleifen ein helles Holzstück mit einem Schleifklotz auf einer Werkbank, daneben liegen zugeschnittene Holzbretter.](assets/images/woodworker_works.jpg "Schleifarbeiten an einem Holzstück in der Tischlerei. Bild von [Detmold via Pixabay](https://pixabay.com/de/photos/tischler-schreiner-handwerk-3280956/), Pixabay Content License, veröffentlicht am 1. April 2018.")<!-- style="max-width: 600px; width: 100%" -->
</center>

## Vorbereiten der Oberfläche - mittelschwere Fragen

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Warum wird Holz vor der Oberflächenbehandlung oft gewässert?

<!-- data-randomize -->
- [( )] Um die Poren zu verschließen.
- [(X)] Um Holzfehler, Leimreste bzw. -durchschläge zu erkennen.
- [( )] Um das Holz aufzuhellen.
- [( )] Um den Feuchtigkeitsgehalt zu senken.

</div>
<div class="flex-child-2 center">
![Rotes Fragezeichen als Symbol für Fragen, Hilfe und Antworten.](assets/images/fragezeichen.jpg "Fragezeichen als Symbol für Fragen, Hilfe und Antworten. Bild von [geralt via Pixabay](https://pixabay.com/de/photos/frage-fragezeichen-hilfe-antwort-2309042/), Pixabay Content License.")<!-- style="max-width: 200px; width: 100%" -->

</div>
</section>


<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Wirkung hat ein Porenfüller auf offenporiges Holz (z. B. Eiche)?

<!-- data-randomize -->
- [( )] Es ändert den Farbton.
- [(X)] Er sorgt für eine glatte, geschlossene Oberfläche.
- [( )] Er verhindert das Verziehen.
- [( )] Er verhindert die Reaktion mit Gerbsäure.

</div>
</section>



## Beizen - mittelschwere Fragen

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Was ist ein typisches Merkmal einer Farbstoffbeize?

<!-- data-randomize -->
- [( )] Reaktion mit Holzinhaltsstoffen
- [(X)] gleichmäßige Färbung durch gelöste Farbpigmente
- [( )] Härtung durch UV-Strahlung
- [( )] Füllung der Poren

</div>
<div class="flex-child-2 center">

![Unregelmäßig übereinanderliegende Holzbretter mit sichtbarer Maserung.](assets/images/lots_of_boards.jpg "Wild übereinanderliegende Holzbretter mit natürlicher Holzstruktur. Bild von [Lantaikayu-biz via Pixabay](https://pixabay.com/de/photos/fu%C3%9Fboden-holz-holzbohlen-parkett-6990002/), Pixabay Content License, veröffentlicht am 5. Februar 2022.") <!-- style="max-width: 300px; width: 100%" -->

</div>
</section>

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Gefahr besteht beim Beizen von Furnier?

<!-- data-randomize -->
- [( )] Poren verschließen sich.
- [(X)] Leimdurchschlag
- [( )] Schimmelbildung
- [( )] Krümmung der Fläche durch Spannung.

>_Florian: Wenn weitere Bilder eingebracht werden sollen, dann bitte welche zur Verfügung stellen!_

</div>
</section>

## Beschichtungsmittel - mittelschwere Fragen

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Überzugsmittel bilden eine elastische, offenporige Schutzschicht?\
Ziehen Sie den richtigen Begriff ins Antwortfeld.

<!-- data-randomize data-show-partial-solution -->
@dragdropmultiple(@uid,Öle,Schellacke|Nitrocellulose-Lacke|Acrylharze)

</div>
</section>

<center>
![Rotes Fragezeichen als Symbol für Fragen, Hilfe und Antworten.](assets/images/fragezeichen.jpg "Fragezeichen als Symbol für Fragen, Hilfe und Antworten. Bild von [geralt via Pixabay](https://pixabay.com/de/photos/frage-fragezeichen-hilfe-antwort-2309042/), Pixabay Content License.")<!-- style="max-width: 200px; width: 100%" -->
</center>


## Oberflächentechniken - mittelschwere Fragen

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Was versteht man unter einem "Zwischenschliff"?

<!-- data-randomize -->
- [( )] Der letzte Schliff nach dem Auftragen von Öl.
- [(X)] Das Schleifen zwischen mehreren Lackschichten.
- [( )] Ein Schleifvorgang vor dem Beizen.
- [( )] Schleifen vor dem Wässern.

</div>
<div class="flex-child-2 center">

![Rotierender Schleifaufsatz einer Bohrmaschine schleift eine Holzleiste, während feiner Holzstaub aufgewirbelt wird.](assets/images/drillpress_sanding.jpg "Schleifwerkzeug beim Bearbeiten einer Holzleiste. Bild von [\_Alicja\_ via Pixabay](https://pixabay.com/de/photos/schleifen-polieren-werkzeuge-4972940/), Pixabay Content License, veröffentlicht am 27. März 2020.") <!-- style="max-width: 300px; width: 100%" -->

</div>
</section>

## Lackauftragsverfahren - mittelschwere Fragen

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Welche Aussage zum Spritzverfahren ist korrekt?

<!-- data-randomize -->
- [( )] Es eignet sich nur für kleine Flächen.
- [(X)] Es ermöglicht einen gleichmäßigen Auftrag auf komplexe Geometrien.
- [( )] Es funktioniert nur mit lösungsfreien Lacken.
- [( )] Es wird ausschließlich bei wasserbasierten Lacken eingesetzt.


</div>
</section>

<center>
![Rotes Fragezeichen als Symbol für Fragen, Hilfe und Antworten.](assets/images/fragezeichen.jpg "Fragezeichen als Symbol für Fragen, Hilfe und Antworten. Bild von [geralt via Pixabay](https://pixabay.com/de/photos/frage-fragezeichen-hilfe-antwort-2309042/), Pixabay Content License.")<!-- style="max-width: 200px; width: 100%" -->
</center>



## Trocknungs- und Härteverfahren - mittelschwere Fragen

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Worin liegt der Vorteil einer Strahlungshärtung (z. B. UV)?

<!-- data-randomize -->
- [( )] wird für Hochglanz benötigt
- [(X)] sehr kurze Aushärtungszeit
- [( )] höhere Oberflächenglätte
- [( )] keine speziellen Lacke erforderlich


</div>
</section>

<center>
![Rotes Fragezeichen als Symbol für Fragen, Hilfe und Antworten.](assets/images/fragezeichen.jpg "Fragezeichen als Symbol für Fragen, Hilfe und Antworten. Bild von [geralt via Pixabay](https://pixabay.com/de/photos/frage-fragezeichen-hilfe-antwort-2309042/), Pixabay Content License.")<!-- style="max-width: 300px; width: 100%" -->
</center>

## Sicherheit und Umweltschutz - mittelschwere Fragen

<section class="flex-container border">
<div class="flex-child">

<!-- class="highlight" -->
Worauf ist beim Umgang mit lösemittelhalthaltigen Lacken besonderes zu achten?

<!-- data-randomize -->
- [( )] gute Farbabdeckung
- [(X)] ausreichende Belüftung und Explosionsschutz
- [( )] Auftragsmenge
- [( )] Trocknung bei Raumtemperatur

</div>
</section>

<center>
![Sicher](assets/images/sicher_aus_schildern.jpg "_Quelle: Pixabay, Peggy+Marco_")<!-- style="max-width: 500px; width: 100%" -->
</center>

## Geschafft! 🙌


<center>
![Bunte Silhouetten mehrerer springender Menschen vor weißem Hintergrund als Symbol für Freude, Spaß und Lebensfreude.](assets/images/colorfull_jumping.jpg "Farbige Silhouetten springender Menschen als Ausdruck von Freude und Spaß. Bild von [geralt via Pixabay](https://pixabay.com/de/illustrations/freude-springen-luftsprung-spa%C3%9F-3940425/), Pixabay Content License, veröffentlicht am 19. Januar 2019.")
</center>
