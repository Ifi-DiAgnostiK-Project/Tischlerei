<!--
author:    Hilke Domsch; Volker Göhler
email:     hilke.domsch@gkz-ev.de; volker.goehler@informatik.tu-freiberg.de
date:      2026-05-04
version:   0.1.0

language:  de
narrator:  Deutsch Male

edit:      https://liascript.github.io/LiveEditor/?/github/Ifi-DiAgnostiK-Project/tischlerei-holzarten-theorie-01

icon:      https://ifi-diagnostik-project.github.io/assets/img/Logo_234px.png
logo:      assets/images/front_wood_stack.jpg

comment:   Einführung in die visuelle Holzartenbestimmung – Merkmale, Härte und
           Einsatzgebiete. Vorbereitung auf das Quiz Holzarten I.
attribute: Titelbilder - Pixabay, webentwicklerin; Holzabbildungen - HWK
           Dresden, Florian Riefling; holzvomfach.de; holz-werken.com

title:     Holzarten – Grundlagen und visuelle Merkmale (Teil 1)

link:      style.css
import:    https://raw.githubusercontent.com/Ifi-DiAgnostiK-Project/Holzarten/refs/heads/main/makros.md

tags:      Tischler,
           Schreiner,
           Holzarten
-->

# Holzarten – Grundlagen und visuelle Merkmale

![Stapel aus vierkantigem Holz, das dicht nebeneinander gelagert ist.](assets/images/front_wood_stack.jpg "Gelagerter Stapel aus Vierkantholz. Bild von [webentwicklerin via Pixabay](https://pixabay.com/de/photos/holz-stapel-vierkant-lagerung-4729934/), Pixabay Content License, veröffentlicht am 31. Dezember 2019.")

---

Stellen Sie sich vor: Sie stehen in der Werkstatt und sollen selbst ein Holz für eine Außenterrasse auswählen. Zwei Bretter liegen vor Ihnen — das eine ist Buche, das andere ist Eiche. Welches nehmen Sie?

Wenn Sie sich nicht sicher sind: Das ist kein Problem — genau das werden Sie nach dieser Lerneinheit wissen.

**Was Sie hier lernen:**

- Wie Sie Holzarten anhand typischer Merkmale **visuell erkennen**
- Was der Unterschied zwischen **Laub- und Nadelholz** ist
- Welche Holzarten **hart** oder **weich** sind — und warum das entscheidend ist
- Welche Hölzer für welche **Einsatzgebiete** geeignet sind

> Danach geht es direkt weiter mit dem **Quiz Holzarten I** — dort können Sie Ihr Wissen sofort an echten Holzbildern anwenden.

## Die Grundeinteilung: Laub- und Nadelholz

    --{{0}}--
Bevor wir uns einzelne Holzarten ansehen, brauchen wir die wichtigste Unterscheidung: Laubholz und Nadelholz. Diese Einteilung sagt Ihnen nicht nur, von welchem Baum das Holz stammt — sie sagt Ihnen auch viel darüber, was Sie von den Eigenschaften erwarten können.

Laubholz kommt von Laubbäumen — Bäume mit breiten Blättern, die im Herbst abgeworfen werden. Nadelholz kommt von Nadelbäumen — immergrün, mit Nadeln. Im Querschnitt ist der Unterschied oft klar sichtbar: Laubhölzer haben ein feineres oder unregelmäßigeres Porenmuster, Nadelhölzer zeigen deutliche Jahresringe.

    --{{1}}--
Aber Vorsicht: "Laubholz" bedeutet nicht automatisch "hart" — und "Nadelholz" nicht automatisch "weich". Das stimmt als Faustregel, hat aber wichtige Ausnahmen. Balsa ist ein Laubholz — und dennoch das weichste Holz der Welt. Lärche ist ein Nadelholz — aber widerstandsfähiger als manches Laubholz.

    {{1}}
<div>

| Merkmal | Laubholz | Nadelholz |
|---|---|---|
| Baumtyp | Laubbäume (Blätter) | Nadelbäume (Nadeln) |
| Porenstruktur | zerstreut-ringporig (Poren gleichmäßig verteilt) oder groß-ringporig (Poren in deutlichen Ringen) | kaum sichtbare Poren |
| Jahresringe | oft schwer erkennbar | meist deutlich sichtbar |
| Härte (Faustregel) | eher hart | eher weich |
| Typische Arten | Eiche, Buche, Ahorn, Birke | Fichte, Lärche, Kiefer |
| Hauptverwendung | Möbel, Innenausbau, Außenbereiche | Bau, Schalung, Verkleidung |

</div>

    --{{2}}--
Merken Sie sich diesen Satz: Die Holzart entscheidet — nicht die Kategorie. Im Quiz zählen die konkreten Eigenschaften der einzelnen Holzart. Den Anfang machen wir mit den drei wichtigsten harten Laubhölzern.

    {{2}}
> **Merksatz:** Laubholz ist nicht automatisch hart — Nadelholz ist nicht automatisch weich. Entscheidend ist die Holzart selbst.

## Laubhölzer – hart: Eiche, Buche, Ahorn

    --{{0}}--
Diese drei harten Laubhölzer begegnen Ihnen im Tischlerhandwerk täglich. Sie unterscheiden sich deutlich im Aussehen — und das müssen Sie erkennen können. Schauen Sie genau hin: Maserung, Farbe, Porenstruktur.

> **Hinweis zu den Holzart-Kürzeln:** Jede Holzart hat zwei Kurzbezeichnungen — Sie sehen sie in Klammern hinter dem Namen:
> - **Zweistellig** (z.B. `EI` für Eiche) — das deutsche **Handelskürzel** nach DIN. Sie finden es auf Lieferscheinen, Materiallisten und Holzkennzeichnungen.
> - **Vierstellig** (z.B. `QCXR`) — eine internationale **botanische Kurzbezeichnung**: die ersten zwei Buchstaben der lateinischen Gattung + die ersten zwei Buchstaben der Artbezeichnung (*Quercus* = Eiche → `QC` + `XR`).
>
> Merken Sie sich die Kürzel hier noch nicht auswendig — das kommt in den Lerneinheiten **Holzarten – Kürzel I und II**. Jetzt genügt es, das System zu kennen.

<section class="flex-container" style="gap: 2rem; padding: 1rem 0; align-items: flex-start;">
<div class="flex-child" style="min-width: 220px;">

<!--style="color:#1A2F5E; font-size: 1.1rem; font-weight: bold;"-->Eiche (EI / QCXR) — sehr hart, dauerhaft

**Erkennungsmerkmale:**

- **Groß-ringporig** — die großen Poren bilden einen deutlichen Ring am Übergang zwischen Früh- und Spätholz; auf dem Hirnholzschnitt als Reihe kleiner Löcher erkennbar
- **Markstrahlen** (der sog. "Spiegel") — Zellstränge, die vom Kern (Mark) sternförmig zur Rinde verlaufen; auf dem Querschnitt als helle, seidig glänzende Streifen sichtbar
- Farbe: **hell- bis mittelbraun**
- **Splint** (helles Außenholz direkt unter der Rinde, jünger und weniger dauerhaft als das Kernholz): hell, schmal — **im Außenbereich nicht verwenden**

**Verwendung:** Außenbereiche (Terrassen, Fenster), Möbelbau (häufig als Furnier), Parkett, anspruchsvolle Tischlerarbeiten

_Warum Außen?_ Eiche wächst langsam — dadurch ist das Holz sehr dicht und widerstandsfähig gegen Feuchtigkeit und Pilzbefall.

</div>
<div class="flex-child" style="max-width: 200px; text-align: center;">

@Hoelzer2.Eiche(25)

_Quelle: HWK Dresden, Florian Riefling_

</div>
</section>

---

<section class="flex-container" style="gap: 2rem; padding: 1rem 0; align-items: flex-start;">
<div class="flex-child" style="min-width: 220px;">

<!--style="color:#1A2F5E; font-size: 1.1rem; font-weight: bold;"-->Buche (BU / FASY) — hart, sehr gleichmäßig

**Erkennungsmerkmale:**

- **Gleichmäßige, feine Struktur** — kaum Maserungsunterschiede
- Farbe: **rötlich-weiß**, sehr homogen — kein dominantes Muster
- Jahresringe nur schwach sichtbar
- Kleine Markstrahlen erkennbar

**Verwendung:** Möbel, Innenausbau, Sperrholzplatten, Furniere, Fußleisten, Brennholz

_Warum Furniere?_ Die **gleichmäßige Färbung** der Buche ist ihr Markenzeichen — überall dasselbe ruhige Bild, perfekt für Furniere, wo ein einheitliches Erscheinungsbild gewünscht ist.

</div>
<div class="flex-child" style="max-width: 200px; text-align: center;">

@Hoelzer1.Buche(25)

_Quelle: HWK Dresden, Florian Riefling_

</div>
</section>

---

<section class="flex-container" style="gap: 2rem; padding: 1rem 0; align-items: flex-start;">
<div class="flex-child" style="min-width: 220px;">

<!--style="color:#1A2F5E; font-size: 1.1rem; font-weight: bold;"-->(Berg-)Ahorn (AH / ACCM) — hart, beinahe weiß

**Erkennungsmerkmale:**

- Farbe: **beinahe weiß** bis leicht cremig — sehr hell
- **Sehr feinporig** — nahezu unsichtbare Poren, glatte Oberfläche
- Kaum Maserungszeichnung sichtbar

**Verwendung:** Massive Tischplatten, Arbeitsplatten, Innenmöbel, Parkett

_Warum Arbeitsflächen?_ Ahorn ist **hart** — deshalb hält er starker Beanspruchung stand. Ein weiches Holz würde sich schnell eindrücken. Das ist die direkte Verbindung zwischen Eigenschaft und Einsatz.

</div>
<div class="flex-child" style="max-width: 200px; text-align: center;">

@Hoelzer1.Ahorn(25)

_Quelle: HWK Dresden, Florian Riefling_

</div>
</section>

**Kurze Zwischenfrage:** Welche der drei harten Laubhölzer ist für den ungeschützten Außenbereich geeignet?

- [( )] Buche
- [(X)] Eiche
- [( )] Ahorn

## Laubhölzer – mittelhart und weich: Birke, Linde, Pappel/Espe

    --{{0}}--
Nicht jede Tischlerarbeit braucht das härteste Holz. Für Sperrholz, Schnitzarbeiten und Innenverkleidungen kommen weichere Laubhölzer zum Einsatz. Diese drei sind prüfungsrelevant — und einer hat eine Besonderheit, die leicht übersehen wird.

<section class="flex-container" style="gap: 2rem; padding: 1rem 0; align-items: flex-start;">
<div class="flex-child" style="min-width: 220px;">

<!--style="color:#1A2F5E; font-size: 1.1rem; font-weight: bold;"-->Birke (BI / BEPU) — mittelhart, zäh, elastisch

**Erkennungsmerkmale:**

- Farbe: **gelblich bis rötlich-weiß** — farblich variabel
- **Sehr feinporig**, zerstreut angeordnet
- Mittelschweres Holz, gut form- und bearbeitbar

**Verwendung:** Sperrholz, Furniere, Innenausbau, Küchenmöbel

_Merken:_ Birke ist vielseitig — mittelhart, günstig, gut verarbeitbar.

</div>
<div class="flex-child" style="max-width: 200px; text-align: center;">

@Hoelzer1.Birke(25)

_Quelle: HWK Dresden, Florian Riefling_

</div>
</section>

---

<section class="flex-container" style="gap: 2rem; padding: 1rem 0; align-items: flex-start;">
<div class="flex-child" style="min-width: 220px;">

<!--style="color:#1A2F5E; font-size: 1.1rem; font-weight: bold;"-->Linde (LI / TIXX) — weich, hell-gelblich, feinporig

**Erkennungsmerkmale:**

- Farbe: **weißlich-gelblich** bis leicht hellbraun
- **Sehr feinporig**, unauffällige, ruhige Maserung
- Leicht, weich — lässt sich gut mit dem Messer bearbeiten

**Verwendung:** Bildhauerei, **Schnitzholz**, Drechselarbeiten, Spielzeug, Jalousielamellen

_Merken:_ Linde ist das klassische **Schnitzholz** — weich genug für feine Details, feinporig genug für eine glatte Schnittfläche. Das Gegenteil von Eiche.

</div>
<div class="flex-child" style="max-width: 200px; text-align: center;">

@Hoelzer1.Linde(25)

_Quelle: HWK Dresden, Florian Riefling_

</div>
</section>

---

<section class="flex-container" style="gap: 2rem; padding: 1rem 0; align-items: flex-start;">
<div class="flex-child" style="min-width: 220px;">

<!--style="color:#1A2F5E; font-size: 1.1rem; font-weight: bold;"-->Pappel / Espe / Aspe (PA / POXX) — weich, wechselhafte Maserung

**Erkennungsmerkmale:**

- Farbe: **hell-gräulich bis gelblich-weiß**
- **Wechselhafte, unregelmäßige Maserung** — kein klar erkennbares Muster
- Leicht, weich, nicht sehr dauerhaft

**Verwendung:** Sperrholz, Verpackungsholz, Streichhölzer, Zündhölzer

**Wichtige Anmerkung für das Quiz:** Espe, Aspe und Zitterpappel bezeichnen ein und dieselbe Baumart (*Populus tremula*). Im Quiz können alle drei als korrekte Antwort gewertet werden — das ist keine Falle, sondern ein Lernziel.

</div>
<div class="flex-child" style="max-width: 200px; text-align: center;">

@Hoelzer1.Pappel(25)

_Quelle: HWK Dresden, Florian Riefling_

</div>
</section>

**Kurze Zwischenfrage:** Pappel, Espe und Aspe sind …

- [( )] Drei verschiedene Holzarten mit ähnlichen Eigenschaften
- [(X)] Dieselbe Baumart (*Populus tremula*) unter verschiedenen Trivialnamen
- [( )] Unterarten der Birke

## Besondere Hölzer: Edel-, Tropen- und Extremhölzer

    --{{0}}--
Neben den heimischen Standardhölzern gibt es einige Arten, die im Tischlerhandwerk und im Quiz eine besondere Rolle spielen — wegen ihrer extremen Eigenschaften oder wegen typischer Einsatzgebiete, die leicht verwechselt werden.

    --{{1}}--
Ein häufiger Fehler im Quiz: Buche und Pappel werden für den Außenbereich gehalten — weil man sie als "stabil" oder "häufig" einschätzt. Beides ist falsch. Buche ist innen zu Hause, Pappel erst recht. Für draußen gilt: Teak und Robinie — und bei heimischen Hölzern: Eiche und Lärche.

    {{0}}
<div>

| Holzart | Typ | Besonderheit | Typisches Einsatzgebiet |
|---|---|---|---|
| **Nussbaum** | Laubholz, heimisch | dunkler Kern, kurze schwarze Poren, edles Erscheinungsbild | Edle Möbel, Furniere |
| **Mahagonie** | Laubholz, tropisch | rötlich-braun, gleichmäßig, gut bearbeitbar | Möbelbau, Innenausbau |
| **Teak** | Laubholz, tropisch | sehr witterungsbeständig durch hohen natürlichen Ölgehalt | **Außenbereich**: Gartenmöbel, Terrassen, Bootsbau |
| **Robinie** | Laubholz, heimisch | groß-ringporig, sehr hart, naturwüchsig widerstandsfähig | **Außenbereich**: Spielplätze, Gartenmöbel, Fensterrahmen |
| **Pockholz** | Laubholz, tropisch | **härtestes Holz der Welt** — sinkt im Wasser | Werkzeugstiele, Gleitlager, Schneidbretter |
| **Balsa** | Laubholz, tropisch | **weichstes und leichtestes Nutzholz** — leichter als Kork | Modellbau, Wärmedämmung, Rettungsmittel |

</div>

    {{1}}
> **Merksatz Außenbereich:** Für ungeschützten Außeneinsatz eignen sich: **Teak, Robinie, Eiche, Lärche**. Nicht geeignet ohne besonderen Schutz: Buche, Pappel, Linde, Fichte.

## Nadelholz: Fichte und Lärche

    --{{0}}--
Fichte und Lärche — das sind die beiden Nadelhölzer, die Sie für das Quiz und für die Praxis kennen müssen. Sie sehen sich auf den ersten Blick ähnlich. Der entscheidende Unterschied steckt in einem einzigen Merkmal, das Sie sich jetzt einprägen.

<section class="flex-container" style="gap: 2rem; padding: 1rem 0; align-items: flex-start;">
<div class="flex-child" style="min-width: 220px;">

<!--style="color:#1A2F5E; font-size: 1.1rem; font-weight: bold;"-->Fichte (FI / PCAB) — Nadelholz, weich, häufig

**Erkennungsmerkmale:**

- Farbe: **hell-gelb bis gelblich-weiß**, leicht rötlich
- Jahresringe deutlich sichtbar
- Angenehmer, harziger Geruch
- Offenporig

**Verwendung:** Bau- und Fensterholz, Wand- und Deckenverkleidung, Innenausbau, günstige Möbel

**Wichtig:** Fichte ist **nicht** für ungeschützten Außeneinsatz geeignet — der Harzgehalt reicht nicht aus, um Witterung dauerhaft standzuhalten.

</div>
<div class="flex-child" style="max-width: 200px; text-align: center;">

@Hoelzer1.Fichte(25)

_Quelle: HWK Dresden, Florian Riefling_

</div>
</section>

---

<section class="flex-container" style="gap: 2rem; padding: 1rem 0; align-items: flex-start;">
<div class="flex-child" style="min-width: 220px;">

<!--style="color:#1A2F5E; font-size: 1.1rem; font-weight: bold;"-->Lärche (LA / LADC) — Nadelholz, mittelhart, harzhaltigkeit

**Erkennungsmerkmale:**

- Farbe: **gelblich-weiß im Splint**, **rotbraun im Kern** — deutlicher Farbunterschied
- Jahresringe klar sichtbar, sehr feinporig
- **Stark harzhaltiger Geruch** — intensiver als Fichte

**Verwendung:** Fassadenschalung, **Außenverkleidung**, Innenausbau, Terrassen

_Warum Außen?_ Die **hohe Harzhaltigkeit** der Lärche macht sie widerstandsfähiger gegen Pilzbefall und Witterung als die Fichte. Das Harz wirkt wie ein natürlicher Schutzstoff. Das ist der wesentliche Unterschied — und eine häufige Quiz-Frage.

</div>
<div class="flex-child" style="max-width: 200px; text-align: center;">

@Hoelzer1.Laerche(25)

_Quelle: HWK Dresden, Florian Riefling_

</div>
</section>

**Kurze Zwischenfrage:** Warum eignet sich Lärche für den Außenbereich, Fichte aber nicht?

- [( )] Lärche hat keine sichtbaren Jahresringe
- [(X)] Lärche enthält deutlich mehr Harz, das natürlich gegen Witterung und Pilzbefall schützt
- [( )] Lärche ist ein Laubholz, Fichte ein Nadelholz

## Holzhärte – Warum ist das wichtig?

    --{{0}}--
Die Holzhärte entscheidet, wie sich ein Holz bearbeiten lässt, wie lange es hält und wofür es geeignet ist. Im Tischlerhandwerk wird Härte nach der Brinell-Härteskala gemessen. Was Sie für Prüfungen und die Praxis brauchen, ist die Einordnung der wichtigsten Holzarten in Gruppen.

> **Was ist die Brinell-Härteskala?**
> Sie misst, wie tief eine Stahlkugel unter definierter Kraft in eine Holzoberfläche eindringt. Je höher die Brinell-Zahl, desto härter das Holz — desto weniger gibt es nach.
> Beispiele: Balsa ca. 1 HB — Buche ca. 34 HB — Pockholz über 300 HB.
> Für die Praxis und das Quiz genügt die Gruppeneinordnung (sehr hart / hart / mittelhart / weich).

    --{{1}}--
Denken Sie an eine Küchenarbeitsplatte. Was würden Sie nehmen — Ahorn oder Fichte? Ahorn ist hart und feinporig, hält Schnitte und Belastung aus. Fichte würde sich eindrücken. Dasselbe Prinzip gilt für Parkett: Eiche und Ahorn statt Fichte. Die Wahl des richtigen Härtegrades ist keine Theorie — es ist tägliche Praxis.

    {{1}}
<div>

| Härtegruppe | Holzarten | Typisches Einsatzgebiet |
|---|---|---|
| **Sehr hart** | Pockholz, Robinie, Eiche | Schwerbelastete Bauteile, Außenbereiche |
| **Hart** | Ahorn, Buche, Nussbaum, Kirschbaum | Arbeitsflächen, Möbel, Parkett |
| **Mittelhart** | Birke, Lärche, Kirsche | Furniere, Innenausbau |
| **Weich** | Fichte, Kiefer, Pappel, Linde | Verkleidung, Schnitzen, Sperrholz |
| **Sehr weich** | Balsa | Modellbau, Sonderanwendungen |

</div>

    --{{2}}--
Und die Einteilung Hartholz versus Weichholz im Quiz: Hartholz — Ahorn, Pockholz, Eiche. Weichholz — Balsa, Fichte. Diese fünf sollten sitzen.

    {{2}}
> **Zum Merken:** Hart = Ahorn, Pockholz, Eiche. Weich = Balsa, Fichte. Das ist keine vollständige Liste — aber das ist, was im Quiz abgefragt wird.

## Einsatzgebiete – Das richtige Holz für den richtigen Zweck

    --{{0}}--
Kein Holz passt für alles. Die richtige Holzauswahl ist eine Kernkompetenz im Tischlerhandwerk. Hier sehen Sie die wichtigsten Kategorien — und die typischen Fehler, die im Quiz gemacht werden.

    --{{1}}--
Die häufigste Fehlerquelle: Fichte wird für den Außenbereich gehalten — weil sie so häufig verwendet wird. Stimmt nicht. Fichte ist ein Innenholz. Buche ebenfalls — obwohl sie hart und belastbar ist, verwittert sie im Freien schnell. Teak und Robinie dagegen sind für draußen gemacht.

    {{0}}
<div>

| Einsatzgebiet | Geeignete Hölzer | Nicht geeignet (häufiger Irrtum) |
|---|---|---|
| **Außenbereich** ungeschützt | Teak, Robinie, Eiche, Lärche | Buche ❌, Pappel ❌, Linde ❌, Fichte ❌ |
| **Möbelbau** (Innen) | Buche, Eiche, Ahorn, Nussbaum, Mahagonie, Fichte | — |
| **Parkett / Fußboden** | Eiche, Ahorn, Buche | Fichte (zu weich) ❌ |
| **Furniere** | Buche, Nussbaum, Kirschbaum, Eiche | — |
| **Schnitzarbeiten** | Linde, Birnbaum | Eiche (zu hart) ❌ |
| **Sperrholz** | Pappel, Birke, Fichte | — |
| **Hochbeanspruchte Flächen** | Ahorn, Buche, Eiche | Fichte ❌, Linde ❌, Pappel ❌ |

</div>

    {{1}}
> **Merksatz Möbelbau:** Buche, Mahagonie, Eiche und Fichte eignen sich alle für den Möbelbau. Das ist breiter als viele denken — auch Fichte gehört dazu (günstige Möbel, Massivholzmöbel Innen). Im Freien dagegen — keine der vier, außer Eiche.

## Zusammenfassung – Das Wichtigste auf einen Blick

    --{{0}}--
Gut — damit haben wir alle Grundlagen durchgearbeitet. Hier noch einmal die wichtigsten Holzarten mit ihren Erkennungsmerkmalen kompakt zusammengefasst. Schauen Sie sich die Tabelle durch — und dann geht es direkt weiter zum Quiz.

    {{0}}
<div>

| Holzart | Typ | Erkennungsmerkmal | Schlüssel-Verwendung |
|---|---|---|---|
| **Eiche** | Laubholz, sehr hart | groß-ringporig, Markstrahlen (Spiegel), hell-mittelbraun | Außen, Möbel, Parkett |
| **Buche** | Laubholz, hart | gleichmäßig rötlich-weiß, feine Markstrahlen | Furniere, Möbel, Innen |
| **Ahorn** | Laubholz, hart | beinahe weiß, sehr feinporig | Arbeitsflächen, Parkett |
| **Birke** | Laubholz, mittelhart | gelblich-weiß, feinporig, variabel | Sperrholz, Furniere |
| **Linde** | Laubholz, weich | hell-gelblich, feinporig, unauffällig | Schnitzen, Bildhauerei |
| **Pappel / Espe / Aspe** | Laubholz, weich | hell-gräulich, wechselhafte Maserung | Sperrholz |
| **Nussbaum** | Laubholz, hart | dunkler Kern, schwarze Poren | Edle Möbel |
| **Teak** | Laubholz (trop.), hart | ölhaltig, witterungsbeständig | **Außen** (Garten, Terrasse) |
| **Robinie** | Laubholz, sehr hart | groß-ringporig, gelb-grün bis goldbraun | **Außen** (Spielplätze, Garten) |
| **Fichte** | Nadelholz, weich | hell-gelb, harziger Geruch, Jahresringe deutlich | Innenausbau, Bau, Möbel |
| **Lärche** | Nadelholz, mittelhart | gelblich-weiß/rotbraun, sehr harzhaltigkeit | Fassade, **Außenverkleidung** |
| **Pockholz** | Laubholz (trop.), extrem hart | sinkt im Wasser | Sonderanwendungen |
| **Balsa** | Laubholz (trop.), extrem weich | leichter als Kork | Modellbau |

</div>

    --{{1}}--
Jetzt ist es Zeit, Ihr Wissen zu testen. Das nachfolgende Quiz "Holzarten I" zeigt Ihnen echte Holzproben — Sie ordnen zu, ergänzen Eigenschaften und entscheiden nach Einsatzgebiet. Nehmen Sie sich die Zusammenfassung noch einmal kurz vor, dann starten Sie. Viel Erfolg.

    {{1}}
> **Nächster Schritt:** ➡ **Quiz Holzarten I** — Holzarten an echten Probenbildern bestimmen, Eigenschaften zuordnen, Einsatzgebiete entscheiden.
